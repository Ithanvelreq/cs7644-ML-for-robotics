This package was built using the ROS tutorial "Writing a Teleoperation Node for a Linux-Supported Joystick"
I want to thank Devarsi Rawal that helped me during this homework.
